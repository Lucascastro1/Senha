<!DOCTYPE html>
<html>
<head>
    <title>Visualizar Senha</title>
</head>
<body>
    <p>Sua senha é:</p>
    <p>{{ $senha->senha }}</p>
</body>
</html>
