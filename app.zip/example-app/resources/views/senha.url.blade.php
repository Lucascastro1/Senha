<!DOCTYPE html>
<html>
<head>
    <title>URL da Senha</title>
</head>
<body>
    <p>A URL da senha gerada é:</p>
    <a href="{{ $url }}" target="_blank">{{ $url }}</a>
</body>
</html>
