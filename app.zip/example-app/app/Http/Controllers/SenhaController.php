<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SenhaController extends Controller
{
    public function criarSenha(Request $request)
    {
        // Obtenha os dados do formulário
        $senhaManual = $request->input('senha');
        $gerarSenhaAleatoria = $request->has('gerarSenha');
        $visualizacoesPermitidas = $request->input('visualizacoes');
        $tempoValidadeHoras = $request->input('tempoValidade');

        // Inicialize a variável $senhaAleatoria
        $senhaAleatoria = null;

        // Lógica para criar senha com base nas escolhas do usuário
        if ($gerarSenhaAleatoria) {
            // Implemente a lógica para gerar uma senha aleatória com base nas políticas de complexidade
            $senhaAleatoria = $this->gerarSenhaAleatoria();
            // Armazene ou retorne a senha aleatória
        }

        // Crie um registro no banco de dados para a senha com informações de visualizações e prazo
        $senha = new Senha(); // Certifique-se de que você tem o modelo Senha definido
        $senha->senha = $senhaAleatoria ?? $senhaManual;
        $senha->visualizacoes_permitidas = $visualizacoesPermitidas;
        $senha->tempo_validade_horas = $tempoValidadeHoras;
        $senha->save();

        // Redirecione o usuário para algum lugar apropriado
    }

    // Método para gerar uma senha aleatória com base nas políticas de complexidade
    private function gerarSenhaAleatoria()
    {
        $caracteresPermitidos = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?';

        return Str::random(8, $caracteresPermitidos);
    }

    public function verificarExpiracao(Senha $senha)
    {
        $agora = now();
        $tempoValidade = $senha->tempo_validade_horas;
        $visualizacoesRestantes = $senha->visualizacoes_permitidas - $senha->visualizacoes_realizadas;

        if ($visualizacoesRestantes <= 0 || $agora->diffInHours($senha->created_at) >= $tempoValidade) {
            // A senha expirou ou todas as visualizações foram usadas
            // Implemente a lógica para bloquear ou eliminar a visualização da senha
            // Redirecione o usuário para uma página de senha expirada
        }

        // Caso contrário, permita que o usuário veja a senha
    }

    public function gerarURL(Senha $senha)
    {
        // Verifique se a senha ainda é válida (baseado na lógica de expiração)
        if ($this->verificarExpiracao($senha)) {
            // Implemente a lógica para gerar uma URL única com base nas informações da senha
            $url = route('visualizarSenha', ['token' => $senha->token]);
            // $senha->token é apenas um exemplo; você deve implementar sua própria lógica de geração de token

            return view('senha.url', ['url' => $url]);
        } else {
            // Redirecione o usuário para uma página de senha expirada ou indisponível
            return redirect()->route('senhaExpirada');
        }
    }

    public function visualizarSenha($token)
    {
        // Recupere a senha com base no token fornecido
        $senha = Senha::where('token', $token)->first(); // Certifique-se de que você tem o modelo Senha definido

        if ($senha && $this->verificarExpiracao($senha)) {
            // Implemente a lógica para exibir a senha ao usuário
            return view('senha.visualizar', ['senha' => $senha]);
        } else {
            // A senha não é válida ou expirou
            // Implemente a lógica para bloquear ou eliminar a visualização da senha
            if ($senha) {
                // Se a senha existir, você pode marcar como usada ou excluí-la do banco de dados, dependendo dos seus requisitos
                $senha->visualizacoes_realizadas++;
                $senha->save();
            }

            // Redirecione o usuário para uma página de senha expirada ou indisponível
            return redirect()->route('senhaExpirada');
        }
    }
}
