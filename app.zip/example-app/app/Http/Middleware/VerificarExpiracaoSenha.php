<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Senha;

class VerificarExpiracaoSenha
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle($request, Closure $next)
    {
        $token = $request->route('token');
        $senha = Senha::where('token', $token)->first();

        if (!$senha || !$this->verificarExpiracao($senha)) {
            // A senha não é válida ou expirou
            // Implemente a lógica para bloquear ou eliminar a visualização da senha
            if ($senha) {
                // Se a senha existir, você pode marcar como usada ou excluí-la do banco de dados, dependendo dos seus requisitos
                $senha->visualizacoes_realizadas++;
                $senha->save();
            }

            // Redirecione o usuário para uma página de senha expirada ou indisponível
            return redirect()->route('senhaExpirada');
        }

        return $next($request);
    }
}
