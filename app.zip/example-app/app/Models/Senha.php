<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

// class Senha extends Model
// {
//     use HasFactory;
// }

class Senha extends Model
{
    protected $fillable = [
        'senha',
        'visualizacoes_permitidas',
        'visualizacoes_realizadas',
        'tempo_validade_horas',
        'token',
    ];

    public function visualizacoes()
    {
        return $this->hasMany(VisualizacaoSenha::class);
    }
}
