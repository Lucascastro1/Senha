<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

// class VisualizacaoSenha extends Model
// {
//     use HasFactory;
// }
class VisualizacaoSenha extends Model
{
    protected $fillable = ['senha_id'];

    public function senha()
    {
        return $this->belongsTo(Senha::class);
    }
}
