<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {return view('criarsenha');});

Route::post('/criarsenha', 'SenhaController@criarSenha')->name('criarSenha');
Route::get('/criarsenha', 'SenhaController@criarSenha')->name('criarSenha');
Route::get('/gerar-url/{senha}', 'SenhaController@gerarURL')->name('gerarURL');
Route::get('/visualizar-senha/{token}', 'SenhaController@visualizarSenha')->name('visualizarSenha');
Route::view('/senha-expirada', 'senha.expirada')->name('senhaExpirada');
Route::get('/visualizar-senha/{token}', 'SenhaController@visualizarSenha')->name('visualizarSenha')->middleware('verificarExpiracaoSenha');


