<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSenhasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
{
    Schema::create('senhas', function (Blueprint $table) {
        $table->id();
        $table->string('senha');
        $table->integer('visualizacoes_permitidas');
        $table->integer('visualizacoes_realizadas')->default(0);
        $table->integer('tempo_validade_horas');
        $table->string('token')->unique(); // Implemente uma lógica para gerar tokens únicos
        $table->timestamps();
    });
}


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('senhas');
    }
}
