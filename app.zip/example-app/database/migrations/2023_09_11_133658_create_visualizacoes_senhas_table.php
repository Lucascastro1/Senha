<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVisualizacoesSenhasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
{
    Schema::create('visualizacoes_senhas', function (Blueprint $table) {
        $table->id();
        $table->unsignedBigInteger('senha_id');
        $table->timestamps();
        $table->foreign('senha_id')->references('id')->on('senhas');
    });
}


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('visualizacoes_senhas');
    }
}
